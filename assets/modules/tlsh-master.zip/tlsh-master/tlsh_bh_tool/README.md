
(1) install tlsh / tlsh python extension
	see README.md and README.python in the root directory of the TLSH library

(2) install the python libraries related to this tool
	cd to the setup directory
	cd to the relevant OS
	follow the instructions in the scripts there

(3) use python tlsh_bh_tool.py to generate query about file
	$ python tlsh_bh_tool.py

	********************************
	*   TLSH BlackHat Tool v1.0    *
	*         Demo Version         *
	********************************
	usage: tlsh_bh_tool.py [-h] [-out OUT] [-restrict RESTRICT] [-tc THREAD_COUNT]
                       file

(4) You will need to get an API key for the file tlsh_bh_tool.cfg
	[Credentials]
	apikey=9I3ArG0RCSgZdXoMIfqPnu4qD3AwyBNV7hbJwCV9Q9M
	user=bh_user

Note:
the script bh_demo.sh shows how to use the tool

